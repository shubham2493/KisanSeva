<?php

require 'Slim/Slim.php';



\Slim\Slim::registerAutoloader();

use \Slim\Slim AS Slim;
require 'db.php';
$app = new Slim();
$app->post('/index', 'index'); 

$app->run();

function index() 
						{											
						$current_id = '1';
						$previous_id = '0';
						$language_id ='0';
						$ans=array();
						$bypass=0;
						$bypassfromapp=0;
						$state_id=1;
						$districtid=3;
						$lat='28.7041';
						$long='77.1025';
						$token = bin2hex(openssl_random_pseudo_bytes(16));
							if(isset($_POST['token']))
							{
									$token=$_POST['token'];
							}
						if(isset($_POST['state_id']))
						{

							$state_id=$_POST['state_id'];
						}
						if(isset($_POST['district_id']))
						{

							$districtid=$_POST['district_id'];
						}
						if(isset($_POST['bypass']))
						{
							$bypassfromapp=$_POST['bypass']; 
						}

						if($_POST['current_id'] != '' && $_POST['previous_id'] != '' && $_POST['language_id'] !='')
						{
						$current_id = $_POST['current_id'];
						$previous_id = $_POST['previous_id'];
						$language_id = $_POST['language_id'];  	
						}
						else
						{
						$Basearray = array("data"=>array(array("language"=>"1","level" => "0","option"=>array("id"=>"0","token"=>$token,"question"=>"यह जानकारी प्राप्त नहीं हो पाएगी","is_child"=>"0","count"=>"0","answer"=>""))));
						$basejson = json_encode($Basearray);
						echo $basejson;
						die;
						}	
						//try {
						$dbCon = getConnection();
						if($bypassfromapp == 11)
						{
						$appQueryData = "SELECT * FROM kisan_Seva_kendra WHERE StateId=:StateId";
						$app_screenData = $dbCon->prepare($appQueryData);
						$app_screenData->bindParam(':StateId', $state_id, PDO::PARAM_STR);
						$app_screenData->execute();
						$result_screenData = $app_screenData->fetchAll(PDO::FETCH_OBJ);

						 $count= count($result_screenData);
						$child=0;
						if($count != 0)
						{
						foreach($result_screenData as $valuecenter){

						$question=$valuecenter->address;
						//$ans[]=array("id"=> "0","question"=> $question,"is_child"=> "$child","parent_id"=> "0","is_userinput"=>"0","state_id"=> $state_id,"district_id"=>$districtid,"bypass"=>"$bypass");		
						$option=array("id"=>"0","question"=>$question,"is_child"=>"$child","token"=>$token,"count"=>"0","address"=>"1","answer"=>$ans);							


						}					
						}
						else
						{
						$question='यह जानकारी उपलब्ध नहीं है ';
						$ans[]=array("id"=> "0","question"=> "","is_child"=> "0","parent_id"=> "0","is_userinput"=>"0","state_id"=> $state_id,"district_id"=>$districtid,"bypass"=>"$bypass");	
$option=array("id"=>"0","question"=>$question,"is_child"=>"1","token"=>$token,"count"=>"0","address"=>"0","answer"=>$ans);													
						}

						$Basearray = array("data"=>array(array("language"=>"1","level" => "0","option"=>$option)));
						}
						elseif($bypassfromapp == 3)
						{
						$child=0;
						try{
							// $homepage = file_get_contents("http://api.openweathermap.org/data/2.5/weather?lat=$lat&lon=$long&APPID=4a7ac08b9c662f07c2a92104d15f6e7e");
							// $r=json_decode($homepage);
						
							// $f= $r->main->temp;
							// $temp = round(($f - 273.15));
							// $main= $r->weather;
							// print_r($main);
							// die;
							// $description= $r->weather[0]->description;
							// $pressure= $r->main->pressure;
							// $humidity= $r->main->humidity;
							// $sea_level= $r->main->sea_level;
							// $grnd_level= $r->main->grnd_level;
							// $wind= $r->wind->speed;
							// $wthr=$main."(".$description.") temp:".$temp." pressure:".$pressure." sea_level:".$sea_level." grnd_level:".$grnd_level." wind:".$wind."";

							// $option=array("id"=>"0","question"=>$wthr,"token"=>$token,"is_child"=>"$child","count"=>"0","address"=>"0","answer"=>$ans);							
							// $Basearray = array("data"=>array(array("language"=>"1","level" => "0","option"=>$option)));
$option=array("id"=>"0","question"=>"यह जानकारी प्राप्त नहीं हो पाएगी","token"=>$token,"is_child"=>"$child","count"=>"0","address"=>"0","answer"=>'');							
						$Basearray = array("data"=>array(array("language"=>"1","level" => "0","option"=>$option)));					
					}
						catch (PDOException $e) {
						$option=array("id"=>"0","question"=>"यह जानकारी प्राप्त नहीं हो पाएगी","token"=>$token,"is_child"=>"$child","count"=>"0","address"=>"0","answer"=>$ans);							
						$Basearray = array("data"=>array(array("language"=>"1","level" => "0","option"=>'')));
						}
						}
						elseif($bypassfromapp == 2)
						{
						$appQueryData = "SELECT sc.*,st.StateName,ds.DistrictName FROM soil_centers sc
						LEFT JOIN states st
						ON st.StateId = sc.StateId
						LEFT JOIN districts ds
						ON 
						ds.DistrictId=sc.DistrictId
						WHERE sc.StateId=:StateId AND sc.DistrictId=:DistrictId";
						$app_screenData = $dbCon->prepare($appQueryData);
						$app_screenData->bindParam(':DistrictId', $districtid, PDO::PARAM_STR);
						$app_screenData->bindParam(':StateId', $state_id, PDO::PARAM_STR);
						$app_screenData->execute();
						$result_screenData = $app_screenData->fetchAll(PDO::FETCH_OBJ);

						$count= count($result_screenData);
						$child=0;
						if($count != 0)
						{
						foreach($result_screenData as $valuecenter){

						$question=$valuecenter->LabName.' '.$valuecenter->Town_Village_Name.' '.$valuecenter->SubDistName.' '.$valuecenter->districtnm.' '.$valuecenter->BlockName.' '.$valuecenter->DistrictName.' '.$valuecenter->StateName.'  Email:'.$valuecenter->Email.' Mobile:'.$valuecenter->Mobile;
						$ans[]=array("id"=> "0","question"=> "क्या आप यह जानकारी एसएमएस द्वारा प्राप्त करना चाहते हैं ? कृपया अपना मोबाइल नंबर नीचे दर्ज करें ","is_child"=> "$child","parent_id"=> "0","is_userinput"=>"1","state_id"=> $state_id,"district_id"=>$districtid,"bypass"=>"0");		
						$option=array("id"=>"0","question"=>$question,"is_child"=>"$child","token"=>$token,"count"=>"0","address"=>"1","answer"=>$ans);							

						}
						}
						else
						{
						$appQueryData = "SELECT sc.*,st.StateName,ds.DistrictName FROM soil_centers sc
						LEFT JOIN states st
						ON st.StateId = sc.StateId
						LEFT JOIN districts ds
						ON 
						ds.DistrictId >= sc.DistrictId
						WHERE sc.StateId=:StateId
						ORDER BY sc.DistrictId
						LIMIT 1";
						$app_screenData = $dbCon->prepare($appQueryData);
			
						$app_screenData->bindParam(':StateId', $state_id, PDO::PARAM_STR);
						$app_screenData->execute();
						$result_screenData = $app_screenData->fetchAll(PDO::FETCH_OBJ);

						$count= count($result_screenData);
						$child=0;
						if($count != 0)
						{
						foreach($result_screenData as $valuecenter){

						$question=$valuecenter->LabName.' '.$valuecenter->Town_Village_Name.' '.$valuecenter->SubDistName.' '.$valuecenter->districtnm.' '.$valuecenter->BlockName.' '.$valuecenter->DistrictName.' '.$valuecenter->StateName.'  Email:'.$valuecenter->Email.' Mobile:'.$valuecenter->Mobile;
						//$ans[]=array("id"=> "0","question"=> $question,"is_child"=> "$child","parent_id"=> "0","is_userinput"=>"0","state_id"=> $state_id,"district_id"=>$districtid,"bypass"=>"$bypass");		
						$option=array("id"=>"0","question"=>$question,"is_child"=>"$child","token"=>$token,"count"=>"0","address"=>"1","answer"=>$ans);							


						}					
						}
						else
						{
                         $question="इस क्षेत्र में मिट्टी परीक्षण केंद्र के बारे में जानकारी उपलब्ध नहीं है|";
						
						$option=array("id"=>"0","question"=>$question,"is_child"=>"$child","token"=>$token,"count"=>"0","address"=>"0","answer"=>$ans);							
						}
						}

						$Basearray = array("data"=>array(array("language"=>"1","level" => "0","option"=>$option)));
						}
						else
						{
						$appQueryData = "SELECT QuestionID as id,Question as question FROM question WHERE QuestionId=:current_id";
						$app_screenData = $dbCon->prepare($appQueryData);
						$app_screenData->bindParam(':current_id', $current_id, PDO::PARAM_STR);
						$app_screenData->execute();
						$result_screenData = $app_screenData->fetch(PDO::FETCH_OBJ);

						$appansData = "SELECT * FROM questionchoice qc
						LEFT JOIN questionchoice_rel qcr ON qc.QuestionChoiceID=qcr.QuestionChoiceID
						WHERE qc.QuestionID=:qid order by qc.QuestionChoiceID";
						$app_ansData = $dbCon->prepare($appansData);
						$app_ansData->bindParam(':qid', $current_id, PDO::PARAM_STR);
						$app_ansData->execute();
						$result_ansData = $app_ansData->fetchAll(PDO::FETCH_OBJ);
						$count= count($result_ansData);
						$child=0;
						if($count != 0 && $_POST['current_id'] !=0)
						{ 
						foreach($result_ansData as $value){
						if($value->is_final == 0)
						{
						$child=1;
						}
						else{
						$child=0;
						}
						$bypass=$value->is_bypass;
						header('Content-Type: text/html; charset=utf-8');
						if($bypass != 0 && $bypass != 3)
						{
						if($bypass ==1 || $bypass ==11)
						{
						$appansstates = "SELECT * from states";	
						}
						elseif($bypass ==2){
						$appansstates = "SELECT * from districts where StateId=$state_id";	
						}

						$app_ansstates = $dbCon->prepare($appansstates);
						$app_ansstates->execute();
						$result_ansstates = $app_ansstates->fetchAll(PDO::FETCH_OBJ);
						$count= count($result_ansstates);
						foreach($result_ansstates as $valuestates){
						if(isset($valuestates->DistrictId))
						{
						$DistrictId=$valuestates->DistrictId;
						}else{
						$DistrictId="0";
						}

						if(isset($valuestates->StateNameHindi))
						{
						$statedistric=$valuestates->StateNameHindi;
						}
						elseif(isset($valuestates->DistrictNameHindi)){
						$statedistric=$valuestates->DistrictNameHindi;	
						}
						else{
						$statedistric="";
						} 

						$nextQuestion=$value->NextQuestionID;
						if($nextQuestion == null)
						{
						$nextQuestion=0;	
						} 

						$ans[]=array("id"=> "$nextQuestion","question"=> $statedistric,"is_child"=> "$child","parent_id"=> $value->QuestionID,"is_userinput"=>$value->is_userinput,"state_id"=> $valuestates->StateId,"district_id"=>$DistrictId,"bypass"=>$bypass);	
						if($statedistric == '' || $statedistric == null)
								{
									$count=0;
								}
						}
						}
						else{
						$nextQuestion=$value->NextQuestionID;
						if($nextQuestion == null)
						{
						$nextQuestion=0;	
						}
						$ans[]=array("id"=> "$nextQuestion","question"=> $value->QuestionChoice,"is_child"=> "$child","parent_id"=> $value->QuestionID,"is_userinput"=>$value->is_userinput,"state_id"=> "0","district_id"=>$districtid,"bypass"=>$bypass);	
						if($value->QuestionChoice == '' || $value->QuestionChoice == null)
								{
									$count=0;
								}
						}
						}
								
						$Basearray = array("data"=>array(array("language"=>"1","level" => "0","option"=>array("id"=>$result_screenData->id,"question"=>$result_screenData->question,"is_child"=>"$child","token"=>$token,"count"=>$count,"address"=>"0","answer"=>$ans))));
						}
						else{
						$Basearray = array("data"=>array(array("language"=>"1","level" => "0","option"=>array("id"=>"0","question"=>"","is_child"=>"$child","token"=>$token,"count"=>"0","address"=>"0","answer"=>$ans))));

						}
						}


						$basejson = json_encode($Basearray);
						echo $basejson;
					
}

?>